Some Perspective — research package
Data vintage: 2026-08-15
Site: https://someperspective.info
Repository: https://github.com/Varnasr/someperspective
Licence: CC BY 4.0 (see LICENSE)

paper/       the full research paper: Markdown source and PDF
documents/   the full document set as standalone HTML
data.json    source of record for every figure on the site
dataset.csv  the same indicators as a flat table
replication_code.{py,R}  index construction (SSI / FCI / DQI)
