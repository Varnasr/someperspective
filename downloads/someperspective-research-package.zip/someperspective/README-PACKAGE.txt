Some Perspective | research package
Data vintage: 2026-10-10
Site: https://someperspective.info
Repository: https://github.com/Varnasr/someperspective
Licence: CC BY 4.0 (see LICENSE)

paper/       the full research paper: Markdown source and PDF
documents/   the full document set as standalone HTML
data.json    source of record for every figure on the site
dataset.csv  the published series and the three indices as a flat table
SP_masterdataset.csv  one row per year with every index input
compute_indices.py  how the SSI, FCI and DQI are computed, with sources
replication_code.{py,R}  reproduce the scorecard from the master dataset
